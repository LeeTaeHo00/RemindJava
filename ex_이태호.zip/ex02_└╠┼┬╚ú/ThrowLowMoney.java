package ex02_이태호;

public class ThrowLowMoney extends Exception{

	public ThrowLowMoney() {
		super("돈이 부족합니다.");
		
	}
	
}
