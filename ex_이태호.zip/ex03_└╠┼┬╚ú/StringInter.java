package ex03_이태호;

public interface StringInter {
	String modify(String str);
}
