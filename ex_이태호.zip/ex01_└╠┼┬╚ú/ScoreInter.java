package ex01_이태호;

public interface ScoreInter {
	void score();
}
