package ex01_이태호;

public class StudentMain {

	public static void main(String[] args) {
		Student st = new Student("이태호", 10, 100);
		st.score();
	}

}
