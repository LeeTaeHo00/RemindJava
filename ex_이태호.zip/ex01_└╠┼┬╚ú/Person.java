package ex01_이태호;

public class Person {
	// 필드
	private String name;
	private int age;
	
	// 생성자
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	// getter setter
	public String getName() {
		return name;
	}
}
