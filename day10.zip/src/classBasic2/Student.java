package classBasic2;
// 11번 : 클래스 특징1(사용자 정의 타입) 여러가지 자료형으로 여거 값을 가질 수 있따
public class Student {

	// 필드
	String name; // 학생이름
	int age; // 학생 나이
	double gpa; // 학점
	
	// 
}
